<?php session_start(); ?>
<?php 
include "config/config.php"; 
$selectCommandBlogs = "SELECT * from blogs where status=1";
$resultBlogs = $conn->query($selectCommandBlogs);
?>
<!doctype html>
<html>
<?php include "layout/head.php"; ?>
<body>
<div class="container">
  <?php include "layout/header.php"; ?>
    
    <?php include "layout/nav.php"; ?>
    
  <div class="mb-4 p-3 p-md-5 text-white rounded bg-aquamarine">
    <div class="col-md-12 px-0">
      <h1 class="display-4 font-italic">Добро пожаловать в мой блог</h1>
      <p class="lead my-3">Меня зовут Маржан. В этом блоге я постараюсь затронуть все темы, касающиеся здоровья и красоты. Будь то полезные советы, спортивные упражнения, питание, маски для лица, волос и т.д. Это своего рода дневник, в котором будут записаны все самые необходимые и действенные советы, испытанные лично мною. Вы можете их здесь читать или добавлять свои полезные советы. </p>
    </div>
  </div>

  <div class="row mb-2">
	<?php include("pages/partial/_blogs.php"); ?>
  </div>
</div>
<?php include "layout/footer.php"; ?>

</body>
</html>