<?php
	define('BASE_URL', 'http://localhost/myblog');
	include('db.php');
?>