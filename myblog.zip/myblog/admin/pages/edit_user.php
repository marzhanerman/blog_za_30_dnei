<?php 
session_start();
include("../config/db.php");
if(isset($_GET["user_id"])){
	$user_id = $_GET["user_id"];
	$sql = "select * from users where id=".$user_id;
	$result = $conn->query($sql);
	$row = $result->fetch_array();
}
?>
<!doctype html>
<html lang="en">
 
<?php include("../layout/head.php"); ?>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        
        <?php include("../layout/navbar.php"); ?>
        <?php include("../layout/left-sidebar.php"); ?>
        <?php include("../db_functions/update_user.php"); ?>
		
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
		<div class="dashboard-wrapper">
			<div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Редактировать пользователя</h5>
                                <div class="card-body">
								<?php if($success==false){ ?>
                                    <form id="validationform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"])."?user_id=".$row["id"]; ?>" method="POST">
										<input type="hidden" name="user_id" required="" class="form-control" value="<?php echo $row["id"]; ?>">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Логин</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="login" required="" placeholder="Type something" class="form-control" value="<?php echo $row["login"]; ?>">
                                            </div>
                                        </div>
										
										<div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">ФИО</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="name" required="" placeholder="Type something" class="form-control" value="<?php echo $row["name"]; ?>">
                                            </div>
                                        </div>
										
										<div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Email</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="email" required="" placeholder="Type something" class="form-control" value="<?php echo $row["email"]; ?>">
                                            </div>
                                        </div>
										
										<div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Статус</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
												<select id="inputStatus" class="form-control" name="isadmin">
													<?php 
														if($row["isadmin"] == true){
															echo "<option selected value='true'>Администратор</option>";
															echo "<option value='false'>Пользователь</option>";
														}
														else if($row["isadmin"] == false){ 
															echo "<option value='true'>Администратор</option>";
															echo "<option selected value='false'>Пользователь</option>";
														}
													?>
												</select>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button type="submit" class="btn btn-space btn-primary">Submit</button>
                                                <button type="button" class="btn btn-space btn-secondary cancel-button">Cancel</button>
                                            </div>
                                        </div>
                                    </form>
								<?php } 
								else{
									echo "Изменения сохранены";
									
								}
								?>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                   
			</div>
			</div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <?php include("../layout/scripts.php"); ?>
	<script>
		$("document").ready(function(){	

		$(".trash").click(function(){
			$("#user_id").val($(this).data('id'));
			$('#myModal').modal('show');
		});
		
		$(".deleteBtn").click(function(event){
			deleteUser($("#user_id").val());
			$('#myModal').modal('hide');
		});
		
		$(".cancel-button").click(function(event){
			window.location.replace("<?php echo BASE_URL."/pages/users.php"; ?>");
		});
		});
		
		function deleteUser(id){
		var data = {"id" : id };
		var url = '<?php echo BASE_URL."/db_functions/delete_user.php"; ?>';
			$.ajax({
				url: url,
				type: "post", 
				dataType: "json",
				data: data,
				success: function(msg, textStatus){
					console.log(msg);
					getUsers();
				},
				error: function(textStatus, errorThrown){
					console.log("ERRRORR "+errorThrown);
				}
			});	
		}
		
		function getUsers(){
			var xhr; 
			if (window.XMLHttpRequest) 
				xhr = new XMLHttpRequest(); 
			else if (window.ActiveXObject) 
				xhr = new ActiveXObject("Msxml2.XMLHTTP");
			else 
				throw new Error("Ajax is not supported by your browser");
			
			xhr.open('GET', '<?php echo BASE_URL."/db_functions/get_all_users.php"; ?>');
			xhr.send(null);
			
			xhr.onreadystatechange = function () {
				if (xhr.readyState < 4)
					$('#users-table tbody').innerHTML = "Loading...";
				else if (xhr.readyState === 4) {
					if (xhr.status == 200 && xhr.status < 300)			
						$('#users-table tbody').html(xhr.responseText);
				}
			}
			
		}
	</script>
</body>
 
</html>