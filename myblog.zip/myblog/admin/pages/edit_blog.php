<?php 
session_start();
include("../config/db.php");
if(isset($_GET["blog_id"])){
	$blog_id = $_GET["blog_id"];
	$sql = "select b.*,  u.login as login from blogs b 
	inner join users u
	on b.user_id = u.id
	where b.id=".$blog_id;
	$result = $conn->query($sql);
	$row = $result->fetch_array();
}
?>
<!doctype html>
<html lang="en">
 
<?php include("../layout/head.php"); ?>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        
        <?php include("../layout/navbar.php"); ?>
        <?php include("../layout/left-sidebar.php"); ?>
        <?php include("../db_functions/update_blog.php"); ?>
		
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
		<div class="dashboard-wrapper">
			<div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Редактировать блог</h5>
                                <div class="card-body">
								<?php if($success==false){ ?>
                                    <form class="form-signin" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
										<input type="hidden" name="user_id" required="true" class="form-control" value="<?php echo $row["user_id"]; ?>">
										<input type="hidden" name="blog_id" required="true" class="form-control" value="<?php echo $row["id"]; ?>">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Название</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="title" required="true" placeholder="Type something" class="form-control" value="<?php echo $row["title"]; ?>">
                                            </div>
                                        </div>
										
										<div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Категория</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
												<select id="inputCategory" class="form-control" name="category">
													<?php 
														$selectCommandCategory = "SELECT * from categories";
														$resultCategory = $conn->query($selectCommandCategory);
														while($rowCategory = $resultCategory->fetch_array()){
															if($rowCategory["id"] == $row["category_id"]){
																echo "<option selected value='".$rowCategory["id"]."'>".$rowCategory["name"]."</option>";
															}
															else{
																echo "<option value='".$rowCategory["id"]."'>".$rowCategory["name"]."</option>";
															}
														}
													?>
												</select>
                                            </div>
                                        </div>
										
										<div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Текст</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <textarea type="text" rows="10" id="inputContent" class="form-control"  required="" autofocus="" name="text"><?php echo $row["content"]; ?></textarea>
                                            </div>
                                        </div>
										
										<div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Статус</label>
											<div class="col-12 col-sm-8 col-lg-6">
                                            <select id="inputStatus" class="form-control" name="status">
													<?php 
															if($row["status"] == true){
																echo "<option selected value='true'>Опубликован</option>";
																echo "<option value='false'>Не опубликован</option>";
															}
															else{
																echo "<option value='true'>Опубликован</option>";
																echo "<option selected value='false'>Не опубликован</option>";
															}
														
													?>
											</select>
											</div>
                                        </div>
										
										<div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Автор</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="login" required="true" placeholder="Type something" class="form-control" disabled='true' value="<?php echo $row["login"]; ?>">
                                            </div>
                                        </div>
										
										<div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Дата создания</label>
											<div class="col-12 col-sm-8 col-lg-6">
                                            <input type="text" class="form-control date-inputmask" id="date-mask" im-insert="true" name="date" value="<?php echo $row["created_date"]; ?>" >
											</div>
                                        </div>
										
										<div class="form-group row">											
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Картинка</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
												<img src="<?php echo "../../../uploads/".$row["picture"];?>" width="100px" />
                                                <input type="file" name="inputImage" placeholder="Type something" class="form-control" value="<?php echo $row["picture"];?>">
												<input type="hidden" name="image" value="<?php echo $row["picture"];?>">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button type="submit" class="btn btn-space btn-primary">Submit</button>
                                                <button type="button" class="btn btn-space btn-secondary cancel-button">Cancel</button>
                                            </div>
                                        </div>
                                    </form>
								<?php } 
								else{
									echo "Изменения сохранены";
									
								}
								?>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                   
			</div>
			</div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <?php include("../layout/scripts.php"); ?>
	<script>
		$("document").ready(function(){	

		$(".trash").click(function(){
			$("#blog_id").val($(this).data('id'));
			$('#myModal').modal('show');
		});
		
		$(".deleteBtn").click(function(event){
			deleteUser($("#blog_id").val());
			$('#myModal').modal('hide');
		});
		
		$(".cancel-button").click(function(event){
			window.location.replace("<?php echo BASE_URL."/pages/blogs.php"; ?>");
		});
		});
		
		function deleteUser(id){
		var data = {"id" : id };
		var url = '<?php echo BASE_URL."/db_functions/delete_blog.php"; ?>';
			$.ajax({
				url: url,
				type: "post", 
				dataType: "json",
				data: data,
				success: function(msg, textStatus){
					console.log(msg);
					getUsers();
				},
				error: function(textStatus, errorThrown){
					console.log("ERRRORR "+errorThrown);
				}
			});	
		}
		
		function getUsers(){
			var xhr; 
			if (window.XMLHttpRequest) 
				xhr = new XMLHttpRequest(); 
			else if (window.ActiveXObject) 
				xhr = new ActiveXObject("Msxml2.XMLHTTP");
			else 
				throw new Error("Ajax is not supported by your browser");
			
			xhr.open('GET', '<?php echo BASE_URL."/db_functions/get_all_blogs.php"; ?>');
			xhr.send(null);
			
			xhr.onreadystatechange = function () {
				if (xhr.readyState < 4)
					$('#users-table tbody').innerHTML = "Loading...";
				else if (xhr.readyState === 4) {
					if (xhr.status == 200 && xhr.status < 300)			
						$('#users-table tbody').html(xhr.responseText);
				}
			}
			
		}
	</script>
</body>
 
</html>