<?php 
session_start();
include("../config/db.php");
$sql = "select c.*, b.title as blog, u.login as user from comments c 
inner join blogs b
on b.id = c.blog_id
inner join users u
on u.id = c.user_id";
$result = $conn->query($sql);
?>
<!doctype html>
<html lang="en">
 
<?php include("../layout/head.php"); ?>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        
        <?php include("../layout/navbar.php"); ?>
        <?php include("../layout/left-sidebar.php"); ?>
		
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
		<div class="dashboard-wrapper">
        <div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Комментарии</h5>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="users-table" class="table table-striped table-bordered first">
                                        <thead>
                                            <tr>
                                                <th>№</th>
                                                <th>Блог</th>
                                                <th>Комментарий</th>
                                                <th>Автор</th>
                                                <th>Дата создания</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                                <?php 
													
													while($row = $result->fetch_array()){
														echo "<tr>";
														echo "<td>".$row["id"]."</td>";
														echo "<td>".$row["blog"]."</td>";
														echo "<td>".$row["text"]."</td>";
														echo "<td>".$row["user"]."</td>";
														echo "<td>".$row["created_date"]."</td>";
														echo '<td><a class="trash" data-id="'.$row["id"].'"><i class="fa fa-trash"></i></a></td>';
														echo "</tr>";
													}
												?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
				<!-- Modal -->
				<div class="modal fade" id="myModal" role="dialog">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
						  <div class="modal-header">
							<h5 class="modal-title">Удалить комментарий</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							  <span aria-hidden="true">&times;</span>
							</button>
						  </div>
						  <div class="modal-body">
							<p>Вы точно хотите комментарий?</p>
						  </div>
						  <div class="modal-footer">
							<input type="hidden" value="" id="comment_id">
							<button type="button" class="btn btn-primary deleteBtn">Удалить</button>
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Отмена</button>
						  </div>
						</div>
					  </div>
				</div>
			</div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <?php include("../layout/scripts.php"); ?>
	<script>
		$("document").ready(function(){	

		$(".trash").click(function(){
			$("#comment_id").val($(this).data('id'));
			$('#myModal').modal('show');
		});
		
		$(".deleteBtn").click(function(event){
			deleteBlog($("#comment_id").val());
			$('#myModal').modal('hide');
		});
		});
		
		function deleteBlog(id){
		var data = {"id" : id };
		var url = '<?php echo BASE_URL."/db_functions/delete_comment.php"; ?>';
			$.ajax({
				url: url,
				type: "post", 
				dataType: "json",
				data: data,
				success: function(msg, textStatus){
					console.log(msg);
					getBlogs();
				},
				error: function(textStatus, errorThrown){
					console.log("ERROR "+errorThrown);
				}
			});	
		}
		
		function getBlogs(){
			var xhr; 
			if (window.XMLHttpRequest) 
				xhr = new XMLHttpRequest(); 
			else if (window.ActiveXObject) 
				xhr = new ActiveXObject("Msxml2.XMLHTTP");
			else 
				throw new Error("Ajax is not supported by your browser");
			
			xhr.open('GET', '<?php echo BASE_URL."/db_functions/get_all_comments.php"; ?>');
			xhr.send(null);
			
			xhr.onreadystatechange = function () {
				if (xhr.readyState < 4)
					$('#users-table tbody').innerHTML = "Loading...";
				else if (xhr.readyState === 4) {
					if (xhr.status == 200 && xhr.status < 300)			
						$('#users-table tbody').html(xhr.responseText);
				}
			}
			
		}
	</script>
</body>
 
</html>