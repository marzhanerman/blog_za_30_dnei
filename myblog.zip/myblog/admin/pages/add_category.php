<?php 
session_start();
include("../config/db.php");
?>
<!doctype html>
<html lang="en">
 
<?php include("../layout/head.php"); ?>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        
        <?php include("../layout/navbar.php"); ?>
        <?php include("../layout/left-sidebar.php"); ?>
        <?php include("../db_functions/insert_category.php"); ?>
		
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
		<div class="dashboard-wrapper">
			<div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Добавить категории</h5>								
                                <div class="card-body">
								<?php if($success==false){ ?>
                                    <form id="validationform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Название</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="name" required="true" placeholder="Type something" class="form-control" value="">
                                            </div>
                                        </div>
										
										
                                        
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button type="submit" class="btn btn-space btn-primary">Submit</button>
                                                <button class="btn btn-space btn-secondary">Cancel</button>
                                            </div>
                                        </div>
                                    </form>
								<?php } 
								else{
									echo "Изменения сохранены";
									
								}
								?>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                   
			</div>
			</div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <?php include("../layout/scripts.php"); ?>
	<script>
		$("document").ready(function(){	

		$(".trash").click(function(){
			$("#cat_id").val($(this).data('id'));
			$('#myModal').modal('show');
		});
		
		$(".deleteBtn").click(function(event){
			deleteUser($("#cat_id").val());
			$('#myModal').modal('hide');
		});
		});
		
		function deleteUser(id){
		var data = {"id" : id };
		var url = '<?php echo BASE_URL."/db_functions/delete_category.php"; ?>';
			$.ajax({
				url: url,
				type: "post", 
				dataType: "json",
				data: data,
				success: function(msg, textStatus){
					console.log(msg);
					getUsers();
				},
				error: function(textStatus, errorThrown){
					console.log("ERRRORR "+errorThrown);
				}
			});	
		}
		
		function getUsers(){
			var xhr; 
			if (window.XMLHttpRequest) 
				xhr = new XMLHttpRequest(); 
			else if (window.ActiveXObject) 
				xhr = new ActiveXObject("Msxml2.XMLHTTP");
			else 
				throw new Error("Ajax is not supported by your browser");
			
			xhr.open('GET', '<?php echo BASE_URL."/db_functions/get_all_categories.php"; ?>');
			xhr.send(null);
			
			xhr.onreadystatechange = function () {
				if (xhr.readyState < 4)
					$('#users-table tbody').innerHTML = "Loading...";
				else if (xhr.readyState === 4) {
					if (xhr.status == 200 && xhr.status < 300)			
						$('#users-table tbody').html(xhr.responseText);
				}
			}
			
		}
	</script>
</body>
 
</html>