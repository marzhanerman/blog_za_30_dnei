<?php
$directoryURI = $_SERVER['REQUEST_URI'];
$path = parse_url($directoryURI, PHP_URL_PATH);
$components = explode('/', $path);
$page = $components[4];
?>
<!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link <?php if(strpos($page, "user") !== FALSE){ echo "active"; }?>" href="<?php echo BASE_URL;?>/pages/users.php" ><i class="fa fa-fw fa-user-circle"></i>Пользователи <span class="badge badge-success">6</span></a>
                            </li>
							<li class="nav-item ">
                                <a class="nav-link <?php if(strpos($page, "blog") !== FALSE){ echo "active"; }?>" href="<?php echo BASE_URL;?>/pages/blogs.php"><i class="fa fa-fw fa-file"></i>Блоги <span class="badge badge-success">6</span></a>
                            </li>
							<li class="nav-item ">
                                <a class="nav-link <?php if(strpos($page, "categ") !== FALSE){ echo "active"; }?>" href="<?php echo BASE_URL;?>/pages/categories.php" ><i class="fa fa-fw fa-list"></i>Категории <span class="badge badge-success">6</span></a>
                            </li>
							<li class="nav-item ">
                                <a class="nav-link <?php if(strpos($page, "comment") !== FALSE){ echo "active"; }?>" href="<?php echo BASE_URL;?>/pages/comments.php" ><i class="fa fa-fw fa-comment"></i>Комментарии <span class="badge badge-success">6</span></a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->