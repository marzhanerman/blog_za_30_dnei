<?php
define('BASE_URL', 'http://localhost/myblog/admin');
if(isset($_SESSION["user_status"])){
	if($_SESSION["user_status"] != true)
		echo $_SESSION["user_status"];
		//header("Location: http://localhost/myblog/pages/no-access.php");
		//die();
}
else{
	header("Location: http://localhost/myblog/pages/signup.php");
	die();
}
?>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="<?php echo BASE_URL; ?>/assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/libs/css/style.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/vendor/charts/chartist-bundle/chartist.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/vendor/charts/morris-bundle/morris.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/vendor/charts/c3charts/c3.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>Concept - Bootstrap 4 Admin Dashboard Template</title>
</head>