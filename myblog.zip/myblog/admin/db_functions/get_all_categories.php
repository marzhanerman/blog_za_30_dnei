<?php	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "myblog";
	define("BASE_URL", "http://localhost/myblog/admin");
	// Create connection
	$conn = new mysqli($servername, $username, $password, $database);
	$conn->set_charset("utf8");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	if ($_SERVER["REQUEST_METHOD"] == "GET") {
		$categories= '';
		$sql = "select * from categories";
		$result = $conn->query($sql);
		while($row = $result->fetch_array()){
			$categories= $categories. "<tr><td>".$row["id"]."</td><td>".$row["name"].'</td><td><a href="'.BASE_URL.'/pages/edit_category.php/?cat_id='.$row["id"].'"><i class="fa fa-pencil-alt"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="trash" data-id="'.$row["id"].'"><i class="fa fa-trash"></i></a></td></tr>';
		}
		echo $categories;
		//echo json_encode(mysqli_fetch_assoc($result));
	}
	$conn->close();
?>