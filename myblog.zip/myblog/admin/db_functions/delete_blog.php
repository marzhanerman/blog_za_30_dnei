<?php	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "myblog";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $database);
	$conn->set_charset("utf8");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$blog_id = $_POST['id'];		
		$deleteSql = "delete from blogs where id=".$blog_id;	
		
		$target_dir = $_SERVER['DOCUMENT_ROOT']."/myblog/uploads/";
		$image =  $_POST['image'];
		if(!empty($image))
			unlink($target_dir.$image);	
		
		if ($conn->query($deleteSql) === TRUE) {
			$success = true;
			echo json_encode($success);
		} else {
			$error = "Ошибка: "  . $conn->error;
			echo json_encode($error);
		}
	}
	$conn->close();
?>