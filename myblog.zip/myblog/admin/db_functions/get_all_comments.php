<?php	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "myblog";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $database);
	$conn->set_charset("utf8");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	if ($_SERVER["REQUEST_METHOD"] == "GET") {
		$comments= '';
		$sql = "select c.*, b.title as blog, u.login as user from comments c 
		inner join blogs b
		on b.id = c.blog_id
		inner join users u
		on u.id = c.user_id";
		$result = $conn->query($sql);
		while($row = $result->fetch_array()){
			$comments= $comments. "<tr><td>".$row["id"]."</td><td>".$row["blog"]."</td><td>".$row["text"]."</td><td>".$row["user"]."</td><td>".$row["created_date"].'<td><a class="trash" data-id="'.$row["id"].'"><i class="fa fa-trash"></i></a></td></tr>';
		}
		echo $comments;
		//echo json_encode(mysqli_fetch_assoc($result));
	}
	$conn->close();
?>