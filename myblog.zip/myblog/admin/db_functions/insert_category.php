<?php	
	$success = false;
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			
		if (isset($_POST["cat_id"])) {
			$cat_id = $_POST["cat_id"];
		}
			
		if (empty($_POST["name"])) {
			$nameErr = "Заполните название";
		} else {
			$name = $_POST["name"];
		}
	  
	  
	  
	  $sql = "INSERT INTO categories(name) VALUES('".$name."')";

	if ($conn->query($sql) === TRUE) {
		$success = true;
		echo json_encode(true);
	} else {
		$error = "Ошибка: " . $sql . "<br>" . $conn->error;
		echo json_encode($error);
	}
	}
?>