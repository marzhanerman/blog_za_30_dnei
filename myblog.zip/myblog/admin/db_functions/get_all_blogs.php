<?php	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "myblog";
	define("BASE_URL", "http://localhost/myblog/admin");
	// Create connection
	$conn = new mysqli($servername, $username, $password, $database);
	$conn->set_charset("utf8");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	if ($_SERVER["REQUEST_METHOD"] == "GET") {
		$blogs= '';
		$sql = "select b.*, c.name as catname, u.login as login from blogs b 
		inner join categories c 
		on b.category_id = c.id
		inner join users u
		on b.user_id = u.id";
		$result = $conn->query($sql);
		while($row = $result->fetch_array()){
			$blogs= $blogs. "<tr>
			<td>".$row["id"]."</td><td>".$row["title"]."</td><td>".$row["catname"]."</td><td>".substr($row["content"],0,50)."...</td><td>".$row["login"]."</td>".$row["created_date"].'</td><td><a href="'.BASE_URL.'/pages/edit_blog.php/?blog_id='.$row["id"].'"><i class="fa fa-pencil-alt"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="trash" data-id="'.$row["id"].'"><i class="fa fa-trash"></i></a></td></tr>';
		}
		echo $blogs;
		//echo json_encode(mysqli_fetch_assoc($result));
	}
	$conn->close();
?>