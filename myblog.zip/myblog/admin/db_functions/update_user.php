<?php	
	$success = false;
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			
			if (isset($_POST["user_id"])) {
				$user_id = $_POST["user_id"];
			}
			
			if (empty($_POST["name"])) {
				$nameErr = "Заполните имя";
			  } else {
				$name = $_POST["name"];
				// check if name only contains letters and whitespace
				if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
				  $nameErr = "ФИО должно состоять из букв и пробелов"; 
				}
			  }
	  
	  if (empty($_POST["login"])) {
		$loginErr = "Заполните логин";
	  } else {
		$login = $_POST["login"];
		/*
		if (!preg_match('/\s/', $login)){
			$loginErr[] = 'Логин не должен содержать пробелов';
		}
		else{
			if(!preg_match("/^[A-Za-z0-9]+$/",$login))
				$loginErr[] = 'Логин может состоять из латинских букв, цифр';
		}*/
	  }
   
	  if (empty($_POST["email"])) {
		$emailErr = "Заполните еmail";
	  } else {
		$email = $_POST["email"];
		// check if e-mail address is well-formed
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		  $emailErr = "Еmail некорректно заполнен"; 
		}
	  }
	  
	 
	$isadmin = $_POST["isadmin"];
	  
	  
	  $sql = "UPDATE users SET name='".$name."', login='".$login."', email='".$email."', isadmin=".$isadmin." where
	  id=".$user_id;

	if ($conn->query($sql) === TRUE) {
		$success = true;
		echo json_encode(true);
	} else {
		$error = "Ошибка: " . $sql . "<br>" . $conn->error;
		echo json_encode($error);
	}
	}
?>