<?php	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "myblog";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $database);
	$conn->set_charset("utf8");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	if ($_SERVER["REQUEST_METHOD"] == "GET") {
		$all_users= '';
		$sql = "select * from users";
		$result = $conn->query($sql);
		while($row = $result->fetch_array()){
			$all_users= $all_users. "<tr>
			<td>".$row["id"]."</td>
			<td>".$row["login"]."</td>
			<td>".$row["name"]."</td>
			<td>".$row["email"]."</td>
			<td>".$row["isadmin"]."</td>
			<td>".$row["created_date"].'</td>
			<td><a href="#"><i class="fa fa-pencil-alt"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="trash" data-id="'.$row["id"].'"><i class="fa fa-trash"></i></a></td>
			</tr>';
		}
		echo $all_users;
		//echo json_encode(mysqli_fetch_assoc($result));
	}
	$conn->close();
?>