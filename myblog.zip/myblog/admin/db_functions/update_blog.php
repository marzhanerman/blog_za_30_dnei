<?php	
		$success = false;
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			
			
			if (empty($_POST["title"])) {
				$titleErr = "Заполните название";
			} else {
				$title = $_POST["title"];
			}
			
			$user_id = $_POST["user_id"];
			$blog_id = $_POST["blog_id"];
			$category = $_POST["category"];
			$text = $_POST["text"];
			$status = $_POST["status"];
			$date = $_POST["date"];
			
	$image='';
	if($_FILES["inputImage"]["name"] != null && isset($_POST["image"])){
		$target_dir = $_SERVER['DOCUMENT_ROOT']."/myblog/uploads/";
		$target_file = $target_dir . $user_id."_".date('dmYHis');
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo(basename( $_FILES["inputImage"]["name"]),PATHINFO_EXTENSION));
		$check = getimagesize($_FILES["inputImage"]["tmp_name"]);
		if($check !== false) {
			$uploadOk = 1;
		} else {
			$imgErr = "File is not an image.";
			$uploadOk = 0;
		}
	  
	  // Check file size
		if ($_FILES["inputImage"]["size"] > 500000) {
			$imgErr =  "Sorry, your file is too large.";
			$uploadOk = 0;
		}
		
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			$imgErr =  "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
		
	
		if ($uploadOk == 0) {
		$imgErr =  "Sorry, your file was not uploaded.";
		// if everything is ok, try to upload file
		} else {
			if (move_uploaded_file($_FILES["inputImage"]["tmp_name"], $target_file.'.'.$imageFileType)) {
				unlink($target_dir.$_POST["image"]);
			} else {
				$imgErr =  "Sorry, there was an error uploading your file.";
			}
		}
		$image = $user_id."_".date('dmYHis').'.'.$imageFileType;
	}
	
	else if($_FILES["inputImage"]["name"] == null && isset($_POST["image"])){
		$image = $_POST["image"];
	}
  
  
$sql = "UPDATE blogs set title='".$title."', status=".$status.", category_id=".$category.", content='".$text."', picture='".$image."', created_date='".$date."' where id=".$blog_id;
	  
	  /*
	  $sql = "UPDATE blogs SET title='".$title."', category_id=".$category.", content='".$text."', status=".$status.", created_date='".$date."', picture='".$inputImage."' where id=".$blog_id;
*/
	if ($conn->query($sql) === TRUE) {
		$success = true;
		echo json_encode(true);
	} else {
		$error = "Ошибка: " . $sql . "<br>" . $conn->error;
		echo json_encode($error);
	}
	}
?>