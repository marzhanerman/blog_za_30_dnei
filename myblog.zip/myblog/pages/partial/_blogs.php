<?php 
$locale_time = setlocale (LC_TIME, 'ru_RU.UTF-8', 'Rus');
function strf_time($format, $timestamp, $locale)
			{
				$date_str = strftime($format, $timestamp);
				if (strpos($locale, '1251') !== false)
				{
					return iconv('cp1251', 'utf-8', $date_str);
				}
				else
				{
					return $date_str;
				}
			}
while($row = $resultBlogs->fetch_array()){?>
    <div class="col-md-6">
      <div class="card flex-md-row mb-4 shadow-sm h-md-250">
        <div class="card-body d-flex flex-column align-items-start">
          <strong class="d-inline-block mb-2 text-primary">
			<?php 
				$selectCommandCat = "SELECT name from categories where id =".$row["category_id"];
				$resultCat = $conn->query($selectCommandCat);
				while($rowCat = $resultCat->fetch_array()){
					echo $rowCat["name"];
				}
			?>
		  </strong>
          <h3 class="mb-0">
            <a class="text-dark" href="<?php echo BASE_URL.'/pages/view_blog.php/?id='.$row["id"]; ?>"><?php  echo $row["title"]; ?></a>
          </h3>
          <div class="mb-1 text-muted"><?php  
			echo strf_time("%Y, %B %e", strtotime($row["created_date"]), $locale_time);
		  ?></div>
          <p class="card-text mb-auto"><?php echo mb_substr($row["content"], 0, 60, "utf8") ?>...</p>
          <a href="<?php echo BASE_URL.'/pages/view_blog.php/?id='.$row["id"]; ?>">Читать...</a>
        </div>
        <img src="<?php echo BASE_URL.'/uploads/'.$row['picture'];?>" class="bd-placeholder-img card-img-right flex-auto d-none d-lg-block" width="200" height="250" />
		<?php if($row["status"]==0){?>
		<p class=" badge mt-1 ml-3" style="position: absolute; font-style: italic; color: #6c757d;">Не опубликован</p>
		<?php } ?>
      </div>
    </div>
	<?php } ?>