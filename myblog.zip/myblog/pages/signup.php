<?php session_start(); ?>
<?php 
include "../config/config.php"; 
include 'commands/sign_user.php';

if(!isset($_SESSION["login"])){
	if(!isset($_SESSION["redirect"]) && isset($_SERVER['HTTP_REFERER']))
		$_SESSION["redirect"] = $_SERVER['HTTP_REFERER'];
}
else{
	if(isset($_SESSION["redirect"]) && $_SESSION["redirect"] != null)
		header("Location: ".$_SESSION["redirect"]);
	else
		header("Location: ".BASE_URL);
}
?>

<!doctype html>
<html>
<?php include "../layout/head.php"; ?>
<body>
<div class="container">

  <?php include "../layout/header.php"; ?>

  <?php include "../layout/nav.php"; ?>
  
  <div class="row justify-content-center">
	  
	    
		<div class="col-4 col-md-offset-5 bg-aquamarine">
		<form class="form-signin" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
			  <div class="text-center mb-4">
				<h1 class="h3 mb-3 font-weight-normal">Войти</h1>
				
			  </div>

			  <div class="form-label-group">
				<input type="text" id="inputLogin" class="form-control" placeholder="Логин" required="" autofocus="" name="login">
				<label for="inputLogin">Логин</label>
				<span class="invalid-feedback  d-block"><?php echo $emailErr;?></span>
			  </div>

			  <div class="form-label-group">
				<input type="password" id="inputPassword" class="form-control" placeholder="Пароль" required="" name="password">
				<label for="inputPassword">Пароль</label>
				<span class="invalid-feedback  d-block"><?php echo $passwordErr;?></span>
			  </div>

			  <div class="checkbox mb-3">
				<label>
				  <input type="checkbox" value="remember-me"> Запомнить
				</label>
			  </div>
			  <span class="invalid-feedback  d-block"><?php echo $error;?></span>
			  <button class="btn btn-lg btn-primary btn-block" type="submit">Войти</button>
			  <div class="checkbox mt-3 mb-5">
				<a href="register.php">
				  Зарегистрироваться
				</a>
			  </div>
			  
			</form>
			</div>
		
	</div>
</div>

<?php include "../layout/footer.php"; ?>
</body>
</html>