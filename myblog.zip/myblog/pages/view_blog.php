<?php 
session_start();
include "../config/config.php"; 

if ($_SERVER["REQUEST_METHOD"] == "GET") {
	$blog_id = $_GET["id"];
	$selectCommandBlog = "SELECT b.*, u.login as login from blogs b inner join users u on u.id=b.user_id where b.id=".$blog_id;
	$resultBlog = $conn->query($selectCommandBlog);
	$rowBlog = $resultBlog->fetch_array();
	
	if(isset($_SESSION["user_id"])){
		$user_id = $_SESSION["user_id"];
		$selectCommandUser = "SELECT * from users where id=".$user_id;
		$resultUser = $conn->query($selectCommandUser);
		$rowUser = $resultUser->fetch_array();
	}
}

?>
<!doctype html>
<html>
<?php include "../layout/head.php"; ?>
<body>
<div class="container">
  <?php include "../layout/header.php"; ?>
    
    <?php include "../layout/nav.php"; ?>
    
  <div class="row mb-2">
	<div class="col-lg-8">
          <!-- Title -->
          <h1 class="mt-4"><?php echo $rowBlog["title"] ?></h1>

          <!-- Author -->
          <p class="lead">
            Автор
            <a href="<?php echo BASE_URL."/pages/blogs.php/?user_id=".$rowBlog["user_id"]; ?>"><?php echo $rowBlog["login"] ?></a>
          </p>

          <hr>
		  
		  <!-- Edit or Delete Blog -->
		  <?php if(isset($_SESSION["user_id"])){
			  if($_SESSION["user_id"] == $rowBlog["user_id"]){
				 ?>
          <a href="<?php echo BASE_URL."/pages/edit_blog.php/?id=".$rowBlog["id"] ?>"><i class="fa fa-pencil-alt"></i> Редактировать</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <a href="#" data-toggle="modal" data-target="#myModal"><i class="fa fa-trash"></i> Удалить</a>
          <hr>
		  <?php } }?>

          <!-- Date/Time -->
          <p>Опубликовано в <?php 
			//header('Content-type: text/html; charset=utf-8');
			$locale_time = setlocale (LC_TIME, 'ru_RU.UTF-8', 'Rus');
			function strf_time($format, $timestamp, $locale)
			{
				$date_str = strftime($format, $timestamp);
				if (strpos($locale, '1251') !== false)
				{
					return iconv('cp1251', 'utf-8', $date_str);
				}
				else
				{
					return $date_str;
				}
			}
			echo strf_time("%e %b %Y, %H:%M", strtotime($rowBlog["created_date"]), $locale_time); ?></p>

          <hr>

          <!-- Preview Image -->
          <img class="img-fluid rounded" src="<?php echo BASE_URL."/uploads/".$rowBlog["picture"]; ?>" alt="">

          <hr>

          <!-- Post Content -->
          <p class="lead"><?php echo $rowBlog["content"]; ?></p>
          <hr>		  
			
			<?php if(isset($_SESSION["user_id"])){ ?>
          <!-- Comments Form -->
          <div class="card my-4">
            <h5 class="card-header">Оставить комментарий:</h5>
            <div class="card-body">
              <form class="comment-form">
                <div class="form-group">
                  <textarea class="comment-form form-control" name="comment" rows="3"></textarea>
				  <input type="hidden" name="user" value="<?php echo $_SESSION["user_id"]; ?>" />
				  <input type="hidden" name="blog" value="<?php echo $blog_id; ?>" />
                </div>
                <button type="submit" class="btn btnComment btn-primary">Отправить</button>
              </form>
            </div>
          </div>
			<?php } ?>

          <!-- Single Comment -->
		  <div id="comments">
			  
		  </div>
          
            </div>
          </div>
		
		<!-- Modal -->
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<h5 class="modal-title">Удалить блог</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body">
					<p>Вы точно хотите удалить блог?</p>
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-primary" onclick="deleteBlog()" >Удалить</button>
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Отмена</button>
				  </div>
				</div>
			  </div>
		</div>
		  
        </div>
    </div>
  </div>
</div>
<?php include "../layout/footer.php"; ?>
<script>
	
	$("document").ready(function(){		
		loadComments();	
		$(".comment-form").submit(function(event){
			event.preventDefault();
			var url = '<?php echo BASE_URL."/pages/commands/add_comment_to_db.php"; ?>';
			var data = $(".comment-form").serializeArray();
			$.ajax({
				url: url,
				type: "post", 
				dataType: "json",
				data: data,
				success: function(msg, textStatus){
					console.log("SUCCESSSS:"+msg);
					loadComments();
				},
				error: function(textStatus, errorThrown){
					console.log("ERRRORR"+errorThrown);
				},
				complete:function(){
					
				}
			});
			return false;
		});		
	});
	
	function deleteBlog(){
		
		var data = {"id" : "<?php echo $rowBlog["id"];?>", "image": "<?php echo $rowBlog["picture"];?>"};
		var url = '<?php echo BASE_URL."/pages/commands/delete_blog_from_db.php"; ?>';
			$.ajax({
				url: url,
				type: "post", 
				dataType: "json",
				data: data,
				success: function(msg, textStatus){
					window.location.replace("<?php echo BASE_URL."/pages/blogs.php/?id=".$rowBlog["user_id"]; ?>");
				},
				error: function(textStatus, errorThrown){
					console.log("ERRRORR "+errorThrown);
				}
			});	
	}
	
	function loadComments(){
		var xhr; 
		if (window.XMLHttpRequest) 
			xhr = new XMLHttpRequest(); 
		else if (window.ActiveXObject) 
			xhr = new ActiveXObject("Msxml2.XMLHTTP");
		else 
			throw new Error("Ajax is not supported by your browser");
		var params = 'blog_id=<?php echo $rowBlog["id"]; ?>';
		xhr.open('POST', '<?php echo BASE_URL."/pages/commands/get_comments_from_db.php"; ?>', true);
		//Send the proper header information along with the request
		http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

		http.onreadystatechange = function() {//Call a function when the state changes.
			if(http.readyState == 4 && http.status == 200) {
				alert(http.responseText);
			}
		}
		http.send(params);
		
	}
</script>
</body>
</html>