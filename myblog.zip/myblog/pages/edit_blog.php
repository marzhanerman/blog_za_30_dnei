<?php 
session_start();
include "../config/config.php"; 
include 'commands/update_blog_in_db.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
	$blog_id = $_GET["id"];
	$selectCommandBlog = "SELECT * from blogs where id=".$blog_id;
	$resultBlog = $conn->query($selectCommandBlog);
	$rowBlog = $resultBlog->fetch_array();
	
	$user_id = $_SESSION["user_id"];
	$selectCommandUser = "SELECT * from users where id=".$user_id;
	$resultUser = $conn->query($selectCommandUser);
	$rowUser = $resultUser->fetch_array();
}

?>
<!doctype html>
<html>
<?php include "../layout/head.php"; ?>
<body>
<div class="container">
  <?php include "../layout/header.php"; ?>
    
    <?php include "../layout/nav.php"; ?>
    
  <div class="row mb-2">
	<div class="col-lg-8">
        <div class="col-9 col-md-offset-5">
			<?php if($success == false){?>
			<form class="form-signin" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
				<div class=" mb-4 mt-4">
					<h1 class="h3 mb-3 font-weight-normal">Редактировать блог</h1>				
				</div>
				<input type="hidden" name="blog_id" value="<?php echo $blog_id;?>">
				<div class="form-label-group">
					<label for="inputName">Название</label>
					<input type="text" id="inputName" class="form-control" placeholder="Название" required="" autofocus="" name="name" value="<?php echo $rowBlog["title"]; ?>">
					<span class="invalid-feedback d-block"><?php echo $nameErr;?></span>
				</div>
				<div class="form-label-group">
					<label for="inputStatus">Статус</label>
					<select id="inputStatus" class="form-control" name="status">
						<?php 
							if($rowBlog["status"] == 0){
								echo "<option value='1'>Опубликован</option>";
								echo "<option selected value='0'>Не опубликован</option>";
							}
							else{
								echo "<option selected value='1'>Опубликован</option>";
								echo "<option value='0'>Не опубликован</option>";
							}
							
						?>
					</select>
				</div>
				<div class="form-label-group">
					<label for="inputCategoty">Категория</label>
					<select id="inputCategoty" class="form-control" name="category">
						<?php 
							$selectCommand = "SELECT * from categories";
							$result = $conn->query($selectCommand);
							while($row = $result->fetch_array()){
								if($row["id"] == $rowBlog["category_id"]){
									echo "<option selected value='".$row["id"]."'>".$row["name"]."</option>";
								}
								else{
									echo "<option value='".$row["id"]."'>".$row["name"]."</option>";
								}
							}
						?>
					</select>
					<span class="invalid-feedback d-block"><?php echo $catErr;?></span>
				</div>
				<div class="form-label-group">
					<label for="inputContent">Текст</label>
					<textarea type="text" rows="10" id="inputContent" class="form-control" placeholder="Текст" required="" autofocus="" name="text"><?php echo $rowBlog["content"]; ?></textarea>
					<span class="invalid-feedback d-block"><?php echo $textErr;?></span>
				</div>
				<div class="form-label-group">
					<img src="<?php echo BASE_URL."/uploads/".$rowBlog["picture"];?>" width="100px" />
					<label for="inputImage">Изменить картинку</label>
					<input type="file" name="inputImage" id="inputImage" value="<?php echo $rowBlog["picture"];?>">
					<input type="hidden" name="image" value="<?php echo $rowBlog["picture"];?>">
					<span class="invalid-feedback d-block"><?php echo $imgErr;?></span>
				</div>
				<span class="invalid-feedback d-block"><?php echo $error;?></span>
				<button class="btn btn-lg btn-primary btn-block mt-3 mb-3" type="submit">Сохранить</button>
			</form>
			<?php } else {
				echo "Блог успешно сохранен";
			}?>
		</div>  
    </div>
  </div>

        </div>
    </div>
  </div>
</div>
<?php include "../layout/footer.php"; ?>
</body>
</html>