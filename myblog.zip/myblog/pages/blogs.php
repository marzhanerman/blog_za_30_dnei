<?php 
session_start();
include "../config/config.php"; 
if ($_SERVER["REQUEST_METHOD"] == "GET") {
	if(isset($_GET["user_id"])){
		$user_id = $_GET["user_id"];
		$selectCommandBlogs = "SELECT * from blogs where user_id=".$user_id." and status = 1";
		if($user_id == $_SESSION["user_id"])
			$selectCommandBlogs = "SELECT * from blogs where user_id=".$user_id;
		$resultBlogs = $conn->query($selectCommandBlogs);
	}
	else if(isset($_GET["cat_id"])){
		$cat_id = $_GET["cat_id"];
		$selectCommandBlogs = "SELECT * from blogs where category_id=".$cat_id." and status = 1";
		$resultBlogs = $conn->query($selectCommandBlogs);
	}
}
else{
	$selectCommandBlogs = "SELECT * from blogs where status=1";
	$resultBlogs = $conn->query($selectCommandBlogs);
}


?>
<!doctype html>
<html>
<?php include "../layout/head.php"; ?>
<body>
<div class="container">
  <?php include "../layout/header.php"; ?>
    
    <?php include "../layout/nav.php"; ?>
    
  <div class="row mb-2">
	<?php include("partial/_blogs.php");?>
  </div>
</div>
<?php include "../layout/footer.php"; ?>

</body>
</html>