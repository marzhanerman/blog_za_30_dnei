<?php
	session_start();
	unset($_SESSION['login']);
	unset($_SESSION['user_id']);
	unset($_SESSION['user_status']);
	unset($_SESSION['redirect']);
	header("Location: ".$_SERVER['HTTP_REFERER']);
	exit();
?>