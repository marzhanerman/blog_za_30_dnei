<?php session_start(); ?>
<?php 
include "../config/config.php"; 
include 'commands/sign_user.php';


?>

<!doctype html>
<html>
<?php include "../layout/head.php"; ?>
<body>
<div class="container">

  <?php include "../layout/header.php"; ?>

  <?php include "../layout/nav.php"; ?>
  
  <div class="row justify-content-center">
	  
	    <?php  if($success == false){ ?>
		<div class="col-4 col-md-offset-5 bg-aquamarine">
			У вас недостаточно прав для просмотра данной страницы
		</div>
			<?php } 
			else { 
				header("Location: ".$_SERVER['HTTP_REFERER']);
				exit();				
				}
			?>
		
	</div>
</div>

<?php include "../layout/footer.php"; ?>
</body>
</html>