<?php 
session_start();
include "../config/config.php"; 
include 'commands/add_blog_to_db.php';

?>

<!doctype html>
<html>
<?php include "../layout/head.php"; ?>
<body>
<div class="container">
  <?php include "../layout/header.php"; ?>

  <?php include "../layout/nav.php"; ?>
  <?php if($_SESSION["login"] !== null ){?>
	<div class="row justify-content-center">
	<div class="col-12">
		<div class="col-9 col-md-offset-5">
			<?php if($success == false){?>
			<form class="form-signin" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
				<div class=" mb-4 mt-4">
					<h1 class="h3 mb-3 font-weight-normal">Создать блог</h1>				
				</div>
				<div class="form-label-group">
					<label for="inputName">Название</label>
					<input type="text" id="inputName" class="form-control" placeholder="Название" required="" autofocus="" name="name">
					<span class="invalid-feedback d-block"><?php echo $nameErr;?></span>
				</div>
				<div class="form-label-group">
					<label for="inputCategoty">Категория</label>
					<select id="inputCategoty" class="form-control" name="category">
						<option value="" disabled selected>Выберите категорию</option>
						<?php 
							$selectCommand = "SELECT * from categories";
							$result = $conn->query($selectCommand);
							while($row = $result->fetch_array()){
								echo "<option value='".$row["id"]."'>".$row["name"]."</option>";
							}
						?>
					</select>
					<span class="invalid-feedback d-block"><?php echo $catErr;?></span>
				</div>
				<div class="form-label-group">
					<label for="inputContent">Текст</label>
					<textarea type="text" rows="10" id="inputContent" class="form-control" placeholder="Текст" required="" autofocus="" name="text"></textarea>
					<span class="invalid-feedback d-block"><?php echo $textErr;?></span>
				</div>
				<div class="form-label-group">
					<label for="inputImage">Загрузите картинку</label>
					<input type="file" name="inputImage" id="inputImage">
					<span class="invalid-feedback d-block"><?php echo $imgErr;?></span>
				</div>
				<span class="invalid-feedback d-block"><?php echo $error;?></span>
				<button class="btn btn-lg btn-primary btn-block mt-3 mb-3" type="submit">Сохранить</button>
			</form>
			<?php } else {
				echo "Блог успешно сохранен";
			}?>
		</div>
		<div class="col-3 col-md-offset-5">
		
		</div>
	</div>
	</div>
	<?php }
	else{
		header("Location: ".BASE_URL."/pages/signup.php");
		die();
	}?>
</div>

<?php 
include "../layout/footer.php"; 
?>
</body>
</html>
