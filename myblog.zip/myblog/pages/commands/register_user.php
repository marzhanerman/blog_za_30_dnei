<?php 

//include '../config/db.php';


$nameErr = $emailErr = $passwordErr = $error = $loginErr = "";
$name = $email = $password = $login = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Заполните имя";
  } else {
    $name = $_POST["name"];
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "ФИО должно состоять из букв и пробелов"; 
    }
  }
  
  if (empty($_POST["login"])) {
    $loginErr = "Заполните логин";
  } else {
    $login = $_POST["login"];
    /*
    if (!preg_match('/\s/', $login)){
		$loginErr[] = 'Логин не должен содержать пробелов';
	}
	else{
		if(!preg_match("/^[A-Za-z0-9]+$/",$login))
			$loginErr[] = 'Логин может состоять из латинских букв, цифр';
	}*/
  }
   
  if (empty($_POST["email"])) {
    $emailErr = "Заполните еmail";
  } else {
    $email = $_POST["email"];
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Еmail некорректно заполнен"; 
    }
  }
 
  if (empty($_POST["password"])) {
    $passwordErr = "Заполните пароль";
  } else {
    $password = $_POST["password"];
    if (strlen($_POST["password"])>5 && !ctype_space($_POST["password"]) && !preg_match('/[^A-Za-z0-9]/', $_POST["password"])) {
      $passwordErr = "Пароль должен состоять из цифр и букв не меньше 5 символов"; 
    }
  }
  

$sql = "INSERT INTO users (name, email, login, password, isadmin)
VALUES ('".$name."', '".$email."', '".$login."', '".sha1($password)."', 0)";

if ($conn->query($sql) === TRUE) {
    $success = true;
} else {
    $error = "Ошибка: " . $sql . "<br>" . $conn->error;
}

}



?>