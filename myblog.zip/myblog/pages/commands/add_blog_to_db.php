<?php 

include '../config/db.php';


$nameErr = $catErr = $textErr = $error = $imgErr = "";
$name = $category = $text = $image = "";
$success = false;



if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$target_dir = $_SERVER['DOCUMENT_ROOT']."/myblog/uploads/";
	$target_file = $target_dir . $_SESSION["user_id"]."_".date('dmYHis');
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo(basename( $_FILES["inputImage"]["name"]),PATHINFO_EXTENSION));
	
	
  if (empty($_POST["name"])) {
    $nameErr = "Заполните название";
  } else {
    $name = $_POST["name"];
  }
  
  if (empty($_POST["category"])) {
    $categoryErr = "Заполните категорию";
  } else {
    $category = $_POST["category"];
  }
  
  if (empty($_POST["text"])) {
    $textErr = "Заполните текст";
  } else {
    $text = $_POST["text"];
  }
  
  
    $check = getimagesize($_FILES["inputImage"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        $imgErr = "File is not an image.";
        $uploadOk = 0;
    }
  
  // Check file size
	if ($_FILES["inputImage"]["size"] > 500000) {
		$imgErr =  "Sorry, your file is too large.";
		$uploadOk = 0;
	}
	
	// Allow certain file formats
	if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	&& $imageFileType != "gif" ) {
		$imgErr =  "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
		$uploadOk = 0;
	}
	
	if ($uploadOk == 0) {
    $imgErr =  "Sorry, your file was not uploaded.";
	// if everything is ok, try to upload file
	} else {
		if (move_uploaded_file($_FILES["inputImage"]["tmp_name"], $target_file.'.'.$imageFileType)) {
			//echo "The file ". basename( $_FILES["inputImage"]["name"]). " has been uploaded.";
		} else {
			$imgErr =  "Sorry, there was an error uploading your file.";
		}
	}
  
  
$sql = "INSERT INTO blogs (title, user_id, category_id, content, picture)
VALUES ('".$name."', ".$_SESSION["user_id"].",".$category.", '".$text."', '".$_SESSION["user_id"]."_".date('dmYHis').'.'.$imageFileType."')";

if ($conn->query($sql) === TRUE) {
    $success = true;
} else {
    $error = "Ошибка: " . $sql . "<br>" . $conn->error;
}

//$conn->close();
}



?>