<?php 
$servername = "localhost";
$username = "root";
$password = "";
$database = "myblog";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
$conn->set_charset("utf8");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$userErr = $commentErr = $blogErr = "";
$user = $comment = $blog = "";
$success = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["user"])) {
	$userErr = "Зарегистрируйтесь, пожалуйста";
	} else {
	$user = $_POST["user"];
	}

	if (empty($_POST["comment"])) {
	$commentErr = "Заполните поле";
	} else {
	$comment = $_POST["comment"];
	}
	$blog = $_POST["blog"];
	$sql = "INSERT INTO comments (user_id, blog_id, text)
	VALUES (".$user.", ".$blog.", '".$comment."')";

	if ($conn->query($sql) === TRUE) {
		$success = true;
		echo json_encode(true);
	} else {
		$error = "Ошибка: " . $sql . "<br>" . $conn->error;
		echo json_encode($error);
	}
	
}
?>