<?php 


$emailErr = $passwordErr = $error = "";
$login = $password = "";
$success = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  if (empty($_POST["login"])) {
    $emailErr = "Заполните логин";
  } else {
      if (empty($_POST["password"])) {
    $passwordErr = "Заполните пароль";
  } else {
    $password = $_POST["password"];
    $login = $_POST["login"];
    
    $selectCommand = "SELECT id, login, password, isadmin from users where login = '".$login."' and password='".sha1($password)."'";
    $result = $conn->query($selectCommand);
    if ($result->num_rows > 0) {
        $success = true;
		$row = $result->fetch_array();
		$_SESSION['login'] = $login;
		$_SESSION['user_id'] = $row["id"];
		$_SESSION['user_status'] = $row["isadmin"];
    } else {
        $error =$selectCommand. "Ошибка: Не совпадают логин или пароль";
    }
	
  }
  
  
  }
  



}



?>