<?php	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "myblog";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $database);
	$conn->set_charset("utf8");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$blog_id = $_POST['blog_id'];
		$sql = "select * from comments where blog_id=";
		$result = $conn->query($sql);
		$comments = '';
		while($row = $result->fetch_array()){
			$findUser = "select * from users where id=".$row["user_id"];
			$userRes = $conn->query($findUser);
			while($user = $userRes->fetch_array())
				$comments = $comments.'
			<div class="media mb-4">
					<img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
					<div class="media-body">
					  <h5 class="mt-0">'.$user["login"].'</h5>
					  '.$row["text"].'
					</div>			
				  </div>
			';
		}
		echo $comments;
	}
	$conn->close();
?>