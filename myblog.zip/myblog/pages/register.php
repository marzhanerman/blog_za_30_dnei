<?php 
include "../config/config.php"; 
include "../config/db.php"; 
include 'commands/register_user.php';
?>

<!doctype html>
<html>
<?php include "../layout/head.php"; ?>
<body>
<div class="container">
  <?php include "../layout/header.php"; ?>

  <?php include "../layout/nav.php"; ?>
  
  <div class="row justify-content-center">
	  <div class="col-4 col-md-offset-5 bg-aquamarine">
	  <?php if($success == false){?>
		<form class="form-signin" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
			  <div class="text-center mb-4 mt-4">
				<h1 class="h3 mb-3 font-weight-normal">Регистрация</h1>
				
			  </div>

			  <div class="form-label-group">
				<label for="inputName">ФИО</label>
				<input type="text" id="inputName" class="form-control" placeholder="ФИО" required="" autofocus="" name="name">
				<span class="invalid-feedback d-block"><?php echo $nameErr;?></span>
			  </div>
			  
			  <div class="form-label-group">
				<label for="inputLogin">Логин</label>
				<input type="text" id="inputLogin" class="form-control" placeholder="Логин" required="" autofocus="" name="login">
				<span class="invalid-feedback  d-block"><?php echo $loginErr;?></span>
			  </div>
			  
			  <div class="form-label-group">
				<label for="inputEmail">Email</label>
				<input type="email" id="inputEmail" class="form-control" placeholder="Email адрес" required="" autofocus="" name="email">				
				<span class="invalid-feedback  d-block"><?php echo $emailErr;?></span>
			  </div>

			  <div class="form-label-group">
				<label for="inputPassword">Пароль</label>
				<input type="password" id="inputPassword" class="form-control" placeholder="Пароль" required="" name="password">
				<span class="invalid-feedback d-block"><?php echo $passwordErr;?></span>
			  </div>

				<span class="invalid-feedback d-block"><?php echo $error;?></span>
			  <button class="btn btn-lg btn-primary btn-block mt-3 mb-3" type="submit">Зарегистрироваться</button>
			</form>
	  <?php } 
	  else {
		  echo "Пользователь успешно зарегистрирован";
	  }
	  ?>
		</div>
	</div>
</div>

<?php include "../layout/footer.php"; ?>
</body>
</html>