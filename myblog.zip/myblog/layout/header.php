
<header class="blog-header py-3">
    <div class="row flex-nowrap justify-content-between align-items-center">
      <div class="col-6 text-left">
	  <a class="blog-header-logo text-dark" href="<?php echo BASE_URL; ?>">Блог о здоровье, красоте и уходе за собой</a>
      </div>
      <div class="col-2 ">
      </div>
      <div class="col-4 d-flex justify-content-end align-items-center">
        <a class="text-muted" href="#">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-3" focusable="false" role="img"><title>Search</title><circle cx="10.5" cy="10.5" r="7.5"></circle><line x1="21" y1="21" x2="15.8" y2="15.8"></line></svg>
        </a>
		<?php if(isset($_SESSION['login'])) {?>
			<ul class="navbar-nav navbar-nav-right">
				  <li class="nav-item nav-profile dropdown">
					<a class="nav-link dropdown-toggle  text-left" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
						<?php echo $_SESSION['login']; ?>
					</a>
					<div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
					  <a class="dropdown-item" href="<?php echo BASE_URL."/pages/blogs.php/?user_id=".$_SESSION["user_id"]?>">
						<i class="mdi mdi-logout mr-2 text-primary"></i>
						Мои блоги
					  </a>
					  <a class="dropdown-item" href="<?php echo BASE_URL."/pages/create_blog.php" ?>">
						<i class="mdi mdi-logout mr-2 text-primary"></i>
						Создать блог
					  </a>
					  <a class="dropdown-item" href=<?php echo BASE_URL."/pages/logout.php"; ?>>
						<i class="mdi mdi-logout mr-2 text-primary"></i>
						Выход
					  </a>
					</div>
				  </li>        
			</ul>
		<?php } 
		else if(!isset($_SESSION['login'])) {?>
			<a class="btn btn-sm btn-outline-secondary" href=<?php echo BASE_URL."/pages/signup.php"; ?>>Войти</a>
		<?php } ?>
      </div>
    </div>
  </header>