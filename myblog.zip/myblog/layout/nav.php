<?php 
$selectCommandNav = "SELECT * from categories";
$resultNav = $conn->query($selectCommandNav);

 ?>
  <div class="nav-scroller py-1 mb-2">
    <nav class="nav d-flex justify-content-between">
		<?php while($rowNav = $resultNav->fetch_array()){?>
		<a class="p-2 text-muted" href="<?php  echo BASE_URL."/pages/blogs.php/?cat_id=".$rowNav["id"]?>"><?php echo $rowNav["name"]; ?></a>
		<?php } ?>
    </nav>
  </div>