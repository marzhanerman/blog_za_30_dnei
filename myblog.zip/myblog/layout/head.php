<?php //define("BASE_URL", "http://localhost/myblog")?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Мой блог</title>
<link rel="stylesheet" href=<?php echo BASE_URL."/assets/style.css" ?> type="text/css">
<link rel="stylesheet" href=<?php echo BASE_URL."/assets/bootstrap-4.2.1-dist/css/bootstrap.min.css" ?> type="text/css">
<link rel="stylesheet" href=<?php echo BASE_URL."/assets/bootstrap-4.2.1-dist/css/bootstrap-grid.min.css" ?> type="text/css">
<link rel="stylesheet" href=<?php echo BASE_URL."/assets/bootstrap-4.2.1-dist/css/bootstrap-reboot.min.css" ?> type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
</head>